<?php

//if (!isset($_SESSION['usuario'])) {
//    header('Location: ../View/Login.php');
//}
//if (isset($_SESSION['usuario'])) {
//    header('Location: ../View/inicio.php');
//} 

class Conexao {

    private $Mongo;
    private $DataBase;
    private $Collection;

    function __construct() {
        $this->Conectar();
    }

    private function Conectar() {
        try {

            $this->Mongo = new MongoClient();
            $this->DataBase = $this->Mongo->SistemadeLog;
        } catch (MongoConnectionException $ex) {
            die($ex->getMessage());
        }
    }

    public function Desconectar() {

        $this->Collection = null;
        $this->DataBase = null;
        $this->Mongo = null;
    }

    public function inserir($sql, $collection) {
        try {

            $this->Collection = $this->DataBase->$collection;
            $results = $this->Collection->insert($sql);

            return $results;
        } catch (PDOException $ex) {
            echo 'Erro na Insercao no Banco: ' . $ex->getMessage();
        }
    }

    public function update($sql, $Collection, $parametros) {
//        try {
//            
//            $this->Collection = $Collection;
//
////            $stm = $this->conexao->prepare($sql);
////            $stm->execute($parametros);
//            return $stm->rowCount();
//            
//            $this->Desconectar();
//            
//            
//        } catch (PDOException $ex) {
//            echo 'Erro na Atualizacao no Banco: ' . $ex->getMessage();
//        }
    }

    public function Consulta($sql, $collection) {
        try {

            $this->Collection = $this->DataBase->$collection;
            $results = $this->Collection->find($sql);

            return $results;
        } catch (PDOException $ex) {
            echo 'Erro na Insercao no Banco: ' . $ex->getMessage();
        }
    }

    public function Excluir($sql, $parametros) {
//        try {
//            $stm = $this->conexao->prepare($sql);
//            $stm->execute($parametros);
//            return $stm->rowCount();
//        } catch (PDOException $ex) {
//            echo 'Erro na Exclusao no Banco: ' . $ex->getMessage();
//        }
    }

}
