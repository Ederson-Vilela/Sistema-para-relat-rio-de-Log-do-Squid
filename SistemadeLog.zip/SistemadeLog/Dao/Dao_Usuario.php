<?php

require_once 'Conexao.php';
require_once '../Model/Usuario.php';

class Dao_usuario {

    public function ImprimeUsuario($nome) {
//        echo $nome;
//        $result = $this->Buscar_UmUsuario($nome);
//        if ($result) {
//            foreach ($result as $user) {
//                $mensagem .=$user;
//            }
//            echo $mensagem;
//        } else {
//            echo '<br><h3>Nenhuma Registro Encontrado</h3><br>';
//        }
    }

    public function insere_Usuario($user) {

        $conect = new Conexao();
        $collection = "Usuario";
        $sql = array(
            'nome' => $user->getNome(),
            'idade' => $user->getIdade(),
            'sexo' => $user->getSexo(),
            'cpf' => $user->getCpf(),
            'email' => $user->getEmail(),
            'estado' => $user->getEstado(),
            'cidade' => $user->getCidade(),
            'rua' => $user->getRua(),
            'numero' => $user->getNumero(),
            'senha' => $user->getSenha(),
            'nivel' => $user->getNivel(),
        );

        if ($result = $conect->inserir($sql, $collection)){
            return TRUE;  
        }  else {
            return FALSE;
        }
        
    }

    public function Buscar_Usuario($nome) {
//
//        $conect = new Conexao();
//        $sql = "SELECT * FROM usuario WHERE nome = :0";
//        $result = $conect->consulta($sql, array($nome));
//        $conect->Desconectar();
//        if ($result) {
//            foreach ($result as $registro) {
//                $busca[] = $this->Montar_Usuario($registro);
//            }
//            return $busca;
//        }
//        return false;
    }

    public function Buscar_TodosUsuario() {

//        $conect = new Conexao();
//        $sql = "SELECT * FROM usuario";
//        $result = $conect->consulta($sql, array());
//        $conect->Desconectar();
//        if ($result) {
//            foreach ($result as $registro) {
//                $busca[] = $this->Montar_Usuario($registro);
//            }
//            return $busca;
//        }
//        return false;
    }

    public function Buscar_TodosFornecedores() {

//        $conect = new Conexao();
//        $sql = "SELECT * FROM usuario WHERE nivel = 3";
//        $result = $conect->consulta($sql, array());
//        $conect->Desconectar();
//        if ($result) {
//            foreach ($result as $registro) {
//                $busca[] = $this->Montar_Usuario($registro);
//            }
//            return $busca;
//        }
//        return false;
    }

    public function BuscarLogin($nome, $senha) {
        $conect = new Conexao();

        $sql = array(
            'cpf' => $nome,
            'senha' => $senha);
        $collection = "Usuario";
        $result = $conect->Consulta($sql, $collection);


        foreach ($result as $results) {
            if ($results) {
                $user = $this->Montar_Usuario($results);
                $conect->Desconectar();
                return $user;
            } else {
                $conect->Desconectar();
                return false;
            }
        }
    }

    public function AlterarUsuario($user) {
//        $conect = new Conexao();
//        $sql = "UPDATE usuario SET nome=?, email=?, cpf=?, nascimento=?, sexo=?, cidade=?, cep=?, "
//                . "estado=?, pais=?, login=?, senha=?, ativo=?, nivel=?, funcao=? WHERE id_usuario =".$user->getId_usuario();
//        
//        
//
//        $parametros = array($user->getNome(), $user->getEmail(), $user->getCpf(),
//            $user->getData_nasc(),$user->getSexo(), $user->getCidade(),$user->getCep(),
//            $user->getEstado(),$user->getPais(), $user->getLogin(), $user->getSenha(),
//            $user->getAtivo(), $user->getNivel(),$user->getFuncao());
//        if ($conect->update($sql, $parametros)){
//            return TRUE;
//        }else{
//            return FALSE;
//        }
    }

    public function Montar_Usuario($registro) {
        $user = new Usuario();
        if ($registro) {
            $user->setId_usuario($registro["_id"]);
            $user->setNome($registro['nome']);
            $user->setIdade($registro['idade']);
            $user->setSexo($registro['sexo']);
            $user->setCpf($registro['cpf']);
            $user->setEmail($registro['email']);
            $user->setEstado($registro['estado']);
            $user->setCidade($registro['cidade']);
            $user->setRua($registro['rua']);
            $user->setNumero($registro['numero']);
            $user->setSenha($registro["senha"]);
            $user->setNivel($registro["nivel"]);
        }


        return $user;
    }

    public function ExcluirUsuario($nome) {

//        $conect = new Conexao();
//        $sql = "DELETE FROM usuario WHERE nome = ?";
//        $parametro = array($nome);
//        if ($conect->Excluir($sql, $parametro)){
//            return TRUE;
//        }else{
//            return FALSE;
//        }
    }

    public function AssociarProduto($id_user, $id_prod) {

//        $conect = new Conexao();
//        $sql = "INSERT INTO fornecedor (id_usuario, id_produto)"
//                . " VALUES (?,?)";
//        $parametro = array($id_user, $id_prod);
//        
//        if ($id = $conect->inserir($sql, $parametro, "fornecedor_id_fornecedor_seq")) {
//            return true;
//        } else {
//            return false;
//        }
    }

}
