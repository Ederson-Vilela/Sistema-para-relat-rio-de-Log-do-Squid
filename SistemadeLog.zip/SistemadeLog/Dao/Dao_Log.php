<?php

require_once 'Conexao.php';
require_once '../Model/Usuario.php';
require_once '../Model/Log.php';

class Dao_Log {

    //db.series.find({name: "Sense 8"}) Retorna a real busca desejada
    //db.series.find({name: {$regex: new RegExp("Sense", "i")}}) retorna todos que tiver a pelo menos a exprecao
    //db.series.find({name: {$regex: new RegExp("Sense", "i")}, year: 2014}) retorna a expressao aonde o ano e igual
    //{data: {$gte: 1326480310, $lte: 1326480311}, metodo: 'GET', ipusuario: '10.1.1.10'}
    //db.Log.find( { data: { $gte: 1326480310, $lte: 1326480311} } ).pretty() retorna igual e no intervalo
    //db.Log.find( { data: { $gte: 1326480310, $lte: 1326480311} } ).pretty() rtorna maior e menor que o intervalo
    //db.series.find({name: "Sense 8"}) Retorna a real busca desejada
    // db.Log.find({data:{$gte: 1326480980, $lt: }})
    //$ db.alunos.find({  nome: {$regex: "e"}  })   # retorna todos os alunos que possuem a letra "e" em algum lugar do nome
    //db.Log.find({Nivel: {$gte: 1}}).sort({TipoConsulta: 1}).pretty(); // O comando “sort” tem como parâmetro 1 (crescente) e -1 (decrescente).
    //        $lt (menor que)
    //$lte (menor ou igual a)
    //$gt (maior que)
    //$gte (maior ou igual a)
    //$all (corresponder a todos os valores em um array)
    //$exists (verificar se um campo existe ounão)
    //$mod (módulo)
    //$ne (não igual)
    //$in (corresponder a um ou mais valores em um array)
    //$nin (corresponder a valores zero em um array)
    //$or (corresponder uma consulta a outra)
    //$nor (não corresponder uma consulta nem outra)
    //$size (corresponder qualquer array com número definido de elementos)
    //$type (corresponder valores com tipo de dados BSON especificado)
    //$not (não igual a)


    public function ImprimeUsuario($nome) {
//        echo $nome;
//        $result = $this->Buscar_UmUsuario($nome);
//        if ($result) {
//            foreach ($result as $user) {
//                $mensagem .=$user;
//            }
//            echo $mensagem;
//        } else {
//            echo '<br><h3>Nenhuma Registro Encontrado</h3><br>';
//        }
    }

    public function insere_Log($ListaLog) {

        $conect = new Conexao();
        $log = new Log();
        $collection = "Log";

        foreach ($ListaLog as $result) {


            $log = $result;
            $sql = array(
                'Data' => $log->getData(),
                'Time' => $log->getTime(),
                'Request' => $log->getRequest(),
                'Ipusuario' => $log->getIpUsuario(),
                'Acao' => $log->getAcao(),
                'Tamanhorequest' => $log->getTamanhoRequest(),
                'Metodo' => $log->getMetodo(),
                'Url' => $log->getUrl(),
                'Ipservidor' => $log->getIpServidor(),
                'Requisicao' => $log->getRequisicao(),
                'Usuario' => $log->getUsuario(),
                'Arquivo' => $log->getArquivo());


            //db.series.find({name: "Sense 8"});
            $result = $conect->inserir($sql, $collection);
        }
        $conect->Desconectar();
    }

    public function Busca_SimpesLog($vetor) {
        $conect = new Conexao();
        $ListaLog = new ArrayObject();
        $collection = "Log";

        if ($vetor[2] != FALSE) {

            $sql = array(
                'Data' => array(
                    '$gte' => (int) $vetor[0],
                    '$lte' => (int) $vetor[1]),
                'Ipusuario' => $vetor[2]
            );
        } else if ($vetor[2] == FALSE) {

            $sql = array(
                'Data' => array(
                    '$gte' => (int) $vetor[0],
                    '$lte' => (int) $vetor[1]
            ));
        }

        $result = $conect->Consulta($sql, $collection);
        $result = $result->sort(array("Data" => 1));

        $results = iterator_to_array($result);

        if (!empty($results)) {
            foreach ($result as $value) {
                $log = new Log();
                $ListaLog->append($this->Montar_Log($value));
            }
            return $ListaLog;
        }

        if (empty($results)) {
            return FALSE;
        }
        $conect->Desconectar();
    }

    public function Buscar_Avancada($vetor) {
        $conect = new Conexao();
        $ListaLog = new ArrayObject();

        $collection = "Log";

        $sql = array(
            'Data' => array(
                '$gte' => (int) $vetor[0],
                '$lte' => (int) $vetor[1]
        ));

         if ($vetor[2] != FALSE) {
            $sql = $sql + array('Metodo' => $vetor[2]);
        }
        
        if ($vetor[3] != FALSE) {
            $sql = $sql + array('Ipusuario' => array('$regex' => $vetor[3]));
        }
        
        if ($vetor[4] != FALSE) {
            $sql = $sql + array('Ipservidor' => array('$regex' => $vetor[4]));
        }
        
        if ($vetor[5] != FALSE) {
            if ($vetor[5] == "interna") {
                
                 $sql = $sql + array('Acao' => array('$nin' => ['TCP_MISS/200','TCP_REFRESH_MISS', 'TCP_CLIENT_REFRESH_MISS']));
                
            }
            }else if ($vetor[5] == "externa") {
            $sql = $sql + array('Acao' => array('$in' => ['TCP_MISS','TCP_REFRESH_MISS', 'TCP_CLIENT_REFRESH_MISS']));
        }
        
        if ($vetor[6] != FALSE) {
            $sql = $sql + array('Url' => array('$regex' => $vetor[6]));
        }


//        if ($vetor[2] == FALSE && $vetor[3] == FALSE && $vetor[4] == FALSE && $vetor[5] == FALSE && $vetor[6] == FALSE) {
//            
//        }

    
        $result = $conect->Consulta($sql, $collection);
        $result = $result->sort(array("Data" => 1));

        $results = iterator_to_array($result);

        if (!empty($results)) {
            foreach ($result as $value) {
                $log = new Log();
                $ListaLog->append($this->Montar_Log($value));
            }
            return $ListaLog;
        }

        if (empty($results)) {
            return FALSE;
        }
        $conect->Desconectar();
    }

    public function Buscar_TodosFornecedores() {

//        $conect = new Conexao();
//        $sql = "SELECT * FROM usuario WHERE nivel = 3";
//        $result = $conect->consulta($sql, array());
//        $conect->Desconectar();
//        if ($result) {
//            foreach ($result as $registro) {
//                $busca[] = $this->Montar_Usuario($registro);
//            }
//            return $busca;
//        }
//        return false;
    }

    public function BuscarLogin($nome, $senha) {
        $conect = new Conexao();

        $sql = array(
            'nome' => $nome,
            'sexo' => $senha);
        $collection = "pessoas";
        $result = $conect->consulta($sql, $collection);

        if ($result) {
            foreach ($result as $results) {

                $user = $this->Montar_Usuario($results);
            }
            $conect->Desconectar();
            return $user;
        }

        return false;
        $conect->Desconectar();
    }

    public function Montar_Log($registro) {
        $log = new Log();
        if ($registro) {
            $log->setId_log($registro["_id"]);

            date_default_timezone_set("Brazil/East");
            $partes = explode(' ', date('d/m/Y H:i:s', (int) $registro['Data']));
            $data = $partes[0];
            $time = $partes[1];
            $log->setData($data);
            $log->setTime($time);

            $log->setRequest($registro['Request']);
            $log->setIpUsuario($registro['Ipusuario']);
            $log->setAcao($registro['Acao']);
            $log->setTamanhoRequest($registro['Tamanhorequest']);
            $log->setMetodo($registro['Metodo']);
            $log->setUrl($registro['Url']);
            $log->setRequisicao($registro['Requisicao']);
            $log->setIpServidor($registro['Ipservidor']);

            $log->setUsuario($registro["Usuario"]);
            $log->setArquivo($registro["Arquivo"]);
        }

        return $log;
    }

    public function ExcluirUsuario($nome) {

//        $conect = new Conexao();
//        $sql = "DELETE FROM usuario WHERE nome = ?";
//        $parametro = array($nome);
//        if ($conect->Excluir($sql, $parametro)){
//            return TRUE;
//        }else{
//            return FALSE;
//        }
    }

    public function AssociarProduto($id_user, $id_prod) {

//        $conect = new Conexao();
//        $sql = "INSERT INTO fornecedor (id_usuario, id_produto)"
//                . " VALUES (?,?)";
//        $parametro = array($id_user, $id_prod);
//        
//        if ($id = $conect->inserir($sql, $parametro, "fornecedor_id_fornecedor_seq")) {
//            return true;
//        } else {
//            return false;
//        }
    }

}
