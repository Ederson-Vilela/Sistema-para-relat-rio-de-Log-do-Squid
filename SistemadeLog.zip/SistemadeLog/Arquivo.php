<?php

require_once './Model/Log.php';
require_once './Control/CTL_Log.php';

$ponteiro = fopen("C:\\xampp\\htdocs\\ArquivoSquid.txt", "r");
$separador = ' ';
$log = new Log();
$CTL = new CTL_Log();
$vetor;
$ListaLog = new ArrayObject(); 

while (!feof($ponteiro)) {
    $vetor = NULL;
    $parte = null;
    $linha = fgets($ponteiro);
    $partes = explode($separador, $linha);

    $i = 0;
    foreach ($partes as $element) {
        if ($element != NULL && $element != "-") {
            $vetor[$i] = $element;
            $i ++;
        }
    }
    $log->setData($vetor[0]);
    $log->setRequest($vetor[1]);
    $log->setIpUsuario($vetor[2]);
    $log->setAcao($vetor[3]);
    $log->setTamanhoRequest($vetor[4]);
    $log->setMetodo($vetor[5]);
    $log->setUrl($vetor[6]);
    $log->setIpServidor($vetor[7]);
    $log->setArquivo($vetor[8]);
    
    echo $log."<br><br>";
    
    $ListaLog -> append($log); 

    
}
echo count($ListaLog);
fclose($ponteiro);
$CTL->InserirLog($ListaLog);
