<?php

if (session_id() == '') {
    session_start();
}
include_once '../Model/Usuario.php';

class Seguranca {

    public static function IniciarSessao($user) {
        $_SESSION["Nome"] = $user->getNome();
        $_SESSION["Nivel"] = $user->getNivel();
    }

    public static function ExpulsarUsuario() {
        unset($_SESSION["Nome"]);
        unset($_SESSION["Nivel"]);
        header("Location: http://localhost/SistemadeLog/View/Logon.php");
    }

    public static function Logout() {
        Seguranca::ExpulsarUsuario();
    }

    public static function ProtegerSession() {
        if (!isset($_SESSION["Nome"])) {
            header("Location: http://localhost/SistemadeLog/View/Logon.php");
            //header("Location: ../View/TelaLogin.php'");
        } else if ($_SESSION["Nivel"] != 1 && $_SESSION["Nivel"] != 2) {
            header("Location: http://localhost/SistemadeLog/View/Logon.php");
            //header("Locatin: ../View/TelaLogin.php'");
        }
    }

    public static function RederecionaUsuario() {
        if ($_SESSION["Nivel"] == 1 || $_SESSION["Nivel"] == 2) {
            header("Location: http://localhost/SistemadeLog/View/PaginaInicial.php");
        }
    }

}
