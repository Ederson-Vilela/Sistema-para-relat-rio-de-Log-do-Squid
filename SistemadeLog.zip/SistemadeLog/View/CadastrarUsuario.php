<?php
if (isset($_POST["criarUser"])) {
    Processa();
} else {
    Tela();
}

function Processa() {
    require_once '../Control/CTL_Usuario.php';
    require_once '../Model/Usuario.php';
    $user = new Usuario();
    $CTL = new CTL_Usuario();

    $user->setNome($_POST["nome"]);
    $user->setIdade($_POST["idade"]);
    $user->setCpf($_POST["cpf"]);
    $user->setEmail($_POST["email"]);
    $user->setRua($_POST["rua"]);
    $user->setNumero($_POST["numero"]);
    $user->setEstado($_POST["estado"]);
    $user->setCidade($_POST["cidade"]);
    $user->setSenha($_POST["senha"]);
    $user->setSexo($_POST["sexo"]);
    $user->setNivel($_POST["nivel"]);


    if ($result = $CTL->InserirUsuario($user)) {
        ?><script>alert("Usuario Inserido com Sucesso")</script><?php
        Tela();
    } else {
        ?><script>alert("Erro na Inserção")</script><?php
    }
}

function Tela() {
    echo '<html lang="pt-br">
    <head> 
        
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sistema de Guarda de Log</title>
        <link href="../CSS/bootstrap.min.css" rel="stylesheet">
        <link href="../CSS/estilo2.css" rel="stylesheet">

        <style>
            body {
                min-height: 1000px;
                padding-top: 30px;
            }
            /*div{
                    border: 4px solid;
                    border-color:yellow;
            }*/
            @media screen and (max-width: 480px) {
                #oculto {
                    display: none;
                }			
            }
        </style>

        <script type="text/javascript">
            $(document).ready(function () {
                $("input[name="documento"]").blur(function () {
                    var nome = $("input[name="nome"]");
                    //var telefone = $("input[name="telefone"]");

                    $(nome).val("Carregando...");
                    //$( telefone ).val("Carregando...");

                    $.getJSON(
                            "function.php",
                            {nome: $(this).val()},
                            function (json)
                            {
                                $(nome).val(json.nome);
                                //$( telefone ).val( json.telefone );
                            }
                    );
                });
            });
        </script>

        <script type="text/javascript">

            var h = 17;
            < !-- - 3 * 3600 Aqui indicas o número de horas a mais ou a menos do servidor (neste caso 3) -- >
                    var m = 30;
            var s = 21;
            function Relogio() {
                if (s >= 59) {
                    s = -1;
                    m = m + 1;
                    if (m >= 60) {
                        m = 00;
                        h = h + 1;
                        if (h >= 24) {
                            h = 00;
                        }
                    }
                }
                s = s + 1;
                if (h <= 9) {
                    xh = "0" + h;
                } else {
                    xh = h;
                }
                if (m <= 9) {
                    xm = "0" + m;
                } else {
                    xm = m;
                }
                if (s <= 9) {
                    xs = "0" + s;
                } else {
                    xs = s;
                }
                document.getElementById("Relogio").innerHTML = xh + ":" + xm + ":" + xs;
                t = setTimeout("Relogio()", 1000);
            }
            -- >
                    function enviarDados() {
                        for (var i = 0; i < document.form.elements.length; i++) {
                            if (document.form.elements[i].disabled) {
                                document.form.elements[i].disabled = false;
                            }
                        }
                        return true;
                    }
        </script>

    </head>

    <body onload="Relogio();">

        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">


                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active">
                            <a class="navbar-brand" href="http://localhost/SistemadeLog/View/Logon.php">Trocar Usúario</a>
                        </li>
                        <li class="active">
                            <a href="http://localhost/SistemadeLog/View/PaginaInicial.php">Inicio</a>
                        </li>
                        <li>
                            <a>
                                <small>OPERANDO POR: Usuario - <span id="Relogio">17:22:38</span></small>
                            </a>
                        </li>
                    </ul>

                    <form class="navbar-form navbar-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-user"><!--Action--></span></button>
                            <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a href="http://localhost/SistemadeLog/View/">Meus Dados</a></li>
                                <li><a href="http://localhost/SistemadeLog/View/">Mudar Senha</a></li>
                                <li class="active"><a href="http://localhost/SistemadeLog/View/"><b>Inserir Usuário</b></a></li>				
                                <li><a href="http://localhost/SistemadeLog/View/"><b>Sair do Sistema</b></a></li>

                            </ul>
                        </div>
                    </form>


                </div>
            </div>
        </nav>
        <script type="text/javascript" src="./Apoio Financeiro - F3 - cadastro - usuario_files/loader.js.download"></script><div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <div class="btn-group pull-right" role="group" aria-label="opções">
                            <a href="http://localhost/SistemadeLog/View/" class="btn btn-primary" >Busca Simples <span class="glyphicon glyphicon-usd" aria-hidden="true"></span></a>
                            <a href="http://localhost/SistemadeLog/View/" class="btn btn-primary" >Busca Avançada <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span></a>
                            <a href="http://localhost/SistemadeLog/View/" class="btn btn-primary" >Administrar Usúario <span class="glyphicon glyphicon-search" aria-hidden="true"></span></a>
                        </div>
                        <h1>SGLE  -  <small> Sistema Gerenciar de Log Empresarial</small></h1>
                    </div>
                </div>	
            </div>
            <h1>Menu  -  <small> Cadastrar Usúario</small></h1>
            <div class="well">
                <!-- HTML form for creating a product -->
                <form action="http://localhost/SistemadeLog/View/CadastrarUsuario.php" method="post">

                    <table class="table table-hover table-responsive table-bordered">

                        <tbody><tr>
                                <td class="col-md-2">Nome</td>
                                <td><input type="text" name="nome" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Idade</td>
                                <td><input type="text" name="idade" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Cpf</td>
                                <td><input type="text" name="cpf" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>E-mail</td>
                                <td><input type="email" name="email" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Rua</td>
                                <td><input type="text" name="rua" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Numero</td>
                                <td><input type="text" name="numero" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Estado</td>
                                <td><input type="text" name="estado" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Cidade</td>
                                <td><input type="text" name="cidade" class="form-control" required=""></td>
                            </tr>


                            <tr>
                                <td>Senha</td>
                                <td><input type="password" name="senha" class="form-control" required=""></td>
                            </tr>

                            <tr>
                                <td>Sexo</td>
                                <td>
                                    <select class="form-control" name="sexo" required="">
                                        <option>Selecione...</option>
                                        <option value="m">Masculino</option>
                                        <option value="f">Feminino</option>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Nivel</td>
                                <td>
                                    <select class="form-control" name="nivel" required="">
                                        <option>Selecione...</option>
                                        <option value="1">Administrativo</option>
                                        <option value="2">Master</option>
                                    </select>	
                                </td>
                            </tr>

                            <tr>
                                <td>Status</td>
                                <td>
                                    <select class="form-control" name="status" required="">
                                        <option>Selecione...</option>
                                        <option value="1">Ativo</option>
                                        <option value="0">bloqueado</option>
                                    </select>	
                                </td>
                            </tr>

                            <tr>
                                <td></td>
                                <td>
                                    <button type="submit" name="criarUser" class="btn btn-primary">Criar Novo Usuário</button>
                                </td>
                            </tr>

                        </tbody></table>
                </form>
            </div>
        </div>
    </body>
</html>';
}
?>
