<?php

//if (isset($_SESSION['usuario'])) {
//    header('Location:inicio.php');
//} else {
if (isset($_POST['Entrar'])) {
    Processa();
} else {
    Logar();
}

function Processa() {

    require_once '../Control/CTL_Usuario.php';
    $CTL = new CTL_Usuario();
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];
    $result = $CTL->ValidarLogin($nome, $senha);
    if (!$result) {
        Logar();
    }
}

function Logar() {
 ?>
<!DOCTYPE html>
<html lang="pt-br"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sistema de Guarda de Log</title>
        <link href="../CSS/bootstrap.min.css" rel="stylesheet">
        <link href="../CSS/estilo2.css" rel="stylesheet">
        <script src="../CSS/jquery.min.js.download"></script>

        <style>
            .back-body:hover{
                background:none repeat scroll 0% 0% #4A708B;

                //color:#fff !important;
                //box-shadow:0px 2px 2px rgba(0, 0, 0, 0.2), 0px 1px 5px rgba(0, 0, 0, 0.2), 0px 0px 0px 12px rgba(255, 255, 255, 0.4);
                //border-radius:5px 20px;
                //cursor:pointer;}

                .form-signin {
                    max-width: 400px;
                    padding: 19px 29px 29px;
                    margin: 0 auto 20px;
                    background-color: #fff;
                    border: 1px solid #e5e5e5;
                    -webkit-border-radius: 5px;
                    -moz-border-radius: 5px;
                    border-radius: 5px;
                    -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
                    -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
                    box-shadow: 0 1px 2px rgba(0,0,0,.05);
                }
            </style>

        </head>

        <body class="loginBody back-body">
<br><br><br><br>
            <div class="container">

                <form class="form-signin text-center" method="POST" action="http://localhost/SistemadeLog/View/Logon.php">

                    <img src="../CSS/user-ico.png" width="90" class="img img-circle">
                    <h3 class="form-signin-heading">Área Restrita</h3>
                    <hr>
                    <div class="form-group">
                        <label class="pull-left">Usuário:</label>
                        <input type="text" value="34659053857" name="nome" class="input-block-level form-control" placeholder="Nome de Usuário" required="">
                        <label class="pull-left">Senha:</label>
                        <input type="password" value="123" name="senha" class="input-block-level form-control" placeholder="Senha" required="">
                    </div>
                    <p class="text-left"><a href="acesso.php">Esqueceu sua senha?</a></p>
                    <button class="btn btn-lg btn-block btn-success" type="submit" name="Entrar"><span class="glyphicon glyphicon-lock"></span> Entrar  </button>
                </form>


                <div class="text-center">
                    <h6>© SisControle - Sistema personalizado de Apoio ao Controle de Log <small>Soluções em Tecnologia de Informação</small> <small>Versão 1.0[Beta]</small></h6>
                </div>	
            </div> 

        </body>
</html>
<?php
}

?>
