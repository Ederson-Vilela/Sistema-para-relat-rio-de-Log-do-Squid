<?php
require_once '../Control/CTL_Log.php';
include_once '../Seguranca.php';
Seguranca::ProtegerSession();



if (isset($_POST["buscar"])) {
    $CTL = new CTL_Log();
    $vetor = array();

    $vetor[0] = $_POST["data1"];
    $vetor[1] = $_POST["hora1"];
    $vetor[2] = $_POST["data2"];
    $vetor[3] = $_POST["hora2"];

    if ($_POST["ip"] == "") {
        $vetor[4] = FALSE;
    } else {
        $vetor[4] = $_POST["ip"];
    }

    $ListaLog = $CTL->Busca_SimplesLog($vetor);



    if (!empty($ListaLog)) {
        $string = '<table border="1" ALIGN="center">
                    <tr bgcolor="GREY">
                          <td WIDTH=110 ALIGN="center">Data Acesso</td>
                          <td WIDTH=90 ALIGN="center">Hora Acesso</td>
                          <td WIDTH=130 ALIGN="center">IP Requisitante</td>
                          <td WIDTH=680 ALIGN="center">Endereço Acessado</td>
                          <td WIDTH=150 ALIGN="center">IP Servidor</td>
                    </tr>';

        $color = '#CFCFCF';
        foreach ($ListaLog as $valor) {
            if ($color == '#CFCFCF') {
                $color = '#FFF5EE';
            } else {
                $color = '#CFCFCF';
            }
            $string = $string .
                    '<tr bgcolor=' . $color . '>
                        <td ALIGN="center">' . $valor->getData() . '</td>
                        <td ALIGN="center">' . $valor->getTime() . '</td>
                        <td ALIGN="center">' . $valor->getIpUsuario() . '</td>
                        <td>' . $valor->getUrl() . '</td>
                        <td ALIGN="center">' . $valor->getIpServidor() . '</td>
                    </tr>';
        }

        $string . '</table>';
        Tela($vetor);
        echo '<br>' . $string;
    } else {
        $string = '<table border="1" ALIGN="center">
                    <tr bgcolor="GREY">
                          <td WIDTH=110 ALIGN="center">Data Acesso</td>
                          <td WIDTH=90 ALIGN="center">Hora Acesso</td>
                          <td WIDTH=130 ALIGN="center">IP Requisitante</td>
                          <td WIDTH=680 ALIGN="center">Endereço Acessado</td>
                          <td WIDTH=150 ALIGN="center">IP Servidor</td>
                    </tr>'
                . '</table>';
        Tela($vetor);
        echo '<br>' . $string;
    }
} else {

    Tela("");
}

function Tela($vetor) {
    ?>
    <html lang="pt-br">
        <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <title>Sistema de Guarda de Log</title>
            <link href="../CSS/bootstrap.min.css" rel="stylesheet">
            <link href="../CSS/estilo2.css" rel="stylesheet">



            <style>

                body {
                    min-height: 1000px;
                    padding-top: 30px;
                }
                /*div{
                    border: 4px solid;
                    border-color:black;
                }*/
            </style>

            <script>
                function mascaraHora(val) {
                    var pass = val.value;
                    var expr = /[0123456789]/;

                    for (i = 0; i < pass.length; i++) {
                        // charAt -> retorna o caractere posicionado no índice especificado
                        var lchar = val.value.charAt(i);
                        var nchar = val.value.charAt(i + 1);

                        if (i == 0) {
                            if ((lchar.search(expr) != 0) || (lchar > 3)) {
                                val.value = "";
                            }

                        } else if (i == 1) {

                            if (lchar.search(expr) != 0) {
                                var tst1 = val.value.substring(0, (i));
                                val.value = tst1;
                                continue;
                            }

                            if ((nchar != ':') && (nchar != '')) {
                                var tst1 = val.value.substring(0, (i) + 1);

                                if (nchar.search(expr) != 0)
                                    var tst2 = val.value.substring(i + 2, pass.length);
                                else
                                    var tst2 = val.value.substring(i + 1, pass.length);

                                val.value = tst1 + ':' + tst2;
                            }

                        } else if (i == 4) {

                            if (lchar.search(expr) != 0) {
                                var tst1 = val.value.substring(0, (i));
                                val.value = tst1;
                                continue;
                            }

                            if ((nchar != ':') && (nchar != '')) {
                                var tst1 = val.value.substring(0, (i) + 1);

                                if (nchar.search(expr) != 0)
                                    var tst2 = val.value.substring(i + 2, pass.length);
                                else
                                    var tst2 = val.value.substring(i + 1, pass.length);

                                val.value = tst1 + ':' + tst2;
                            }
                        }

                        if (i >= 6) {
                            if (lchar.search(expr) != 0) {
                                var tst1 = val.value.substring(0, (i));
                                val.value = tst1;
                            }
                        }
                    }

                    if (pass.length > 7)
                        val.value = val.value.substring(0, 7);
                    return true;
                }
                function mascaraData(val) {
                    var pass = val.value;
                    var expr = /[0123456789]/;

                    for (i = 0; i < pass.length; i++) {
                        // charAt -> retorna o caractere posicionado no índice especificado
                        var lchar = val.value.charAt(i);
                        var nchar = val.value.charAt(i + 1);

                        if (i == 0) {
                            if ((lchar.search(expr) != 0) || (lchar > 3)) {
                                val.value = "";
                            }

                        } else if (i == 1) {

                            if (lchar.search(expr) != 0) {
                                var tst1 = val.value.substring(0, (i));
                                val.value = tst1;
                                continue;
                            }

                            if ((nchar != '/') && (nchar != '')) {
                                var tst1 = val.value.substring(0, (i) + 1);

                                if (nchar.search(expr) != 0)
                                    var tst2 = val.value.substring(i + 2, pass.length);
                                else
                                    var tst2 = val.value.substring(i + 1, pass.length);

                                val.value = tst1 + '/' + tst2;
                            }

                        } else if (i == 4) {

                            if (lchar.search(expr) != 0) {
                                var tst1 = val.value.substring(0, (i));
                                val.value = tst1;
                                continue;
                            }

                            if ((nchar != '/') && (nchar != '')) {
                                var tst1 = val.value.substring(0, (i) + 1);

                                if (nchar.search(expr) != 0)
                                    var tst2 = val.value.substring(i + 2, pass.length);
                                else
                                    var tst2 = val.value.substring(i + 1, pass.length);

                                val.value = tst1 + '/' + tst2;
                            }
                        }

                        if (i >= 6) {
                            if (lchar.search(expr) != 0) {
                                var tst1 = val.value.substring(0, (i));
                                val.value = tst1;
                            }
                        }
                    }

                    if (pass.length > 10)
                        val.value = val.value.substring(0, 10);
                    return true;
                }
            </script>

            <script type="text/javascript">
                $(document).ready(function () {
                    $("input[name='documento']").blur(function () {
                        var nome = $("input[name='nome']");
                        //var telefone = $("input[name='telefone']");
                        $(nome).val('Carregando...');
                        //$( telefone ).val('Carregando...');
                        $.getJSON(
                                'function.php',
                                {nome: $(this).val()},
                                function (json) {
                                    $(nome).val(json.nome);
                                    //$( telefone ).val( json.telefone );
                                }
                        );
                    });
                });
            </script>

            <script type="text/javascript">
                var h = 17;
                < !-- - 3 * 3600 Aqui indicas o número de horas a mais ou a menos do servidor (neste caso 3) -- >
                        var m = 21;
                var s = 47;
                function Relogio() {
                    if (s >= 59) {
                        s = -1;
                        m = m + 1;
                        if (m >= 60) {
                            m = 00;
                            h = h + 1;
                            if (h >= 24) {
                                h = 00;
                            }
                        }
                    }
                    s = s + 1;
                    if (h <= 9) {
                        xh = "0" + h;
                    } else {
                        xh = h;
                    }
                    if (m <= 9) {
                        xm = "0" + m;
                    } else {
                        xm = m;
                    }
                    if (s <= 9) {
                        xs = "0" + s;
                    } else {
                        xs = s;
                    }
                    document.getElementById("Relogio").innerHTML = xh + ":" + xm + ":" + xs;
                    t = setTimeout("Relogio()", 1000);
                }
                -- >
                        function enviarDados() {
                            for (var i = 0; i < document.form.elements.length; i++) {
                                if (document.form.elements[i].disabled) {
                                    document.form.elements[i].disabled = false;
                                }
                            }
                            return true;
                        }
            </script>



        </head>

        <body onload="Relogio();">

            <nav class="navbar navbar-inverse navbar-fixed-top">
                <div class="container">


                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a class="navbar-brand" href="http://localhost/SistemadeLog/View/Logon.php">Trocar Usúario</a>
                            </li>
                            <li class="active">
                                <a href="http://localhost/SistemadeLog/View/PaginaInicial.php">Inicio</a>
                            </li>
                            <li>
                                <a>
                                    <small>OPERANDO POR: Usuario - <span id="Relogio">17:22:38</span></small>
                                </a>
                            </li>
                        </ul>

                        <form class="navbar-form navbar-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-user"><!--Action--></span></button>
                                <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="caret"></span>
                                    <span class="sr-only">Toggle Dropdown</span>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a href="http://localhost/SistemadeLog/View/">Meus Dados</a></li>
                                    <li><a href="http://localhost/SistemadeLog/View/">Mudar Senha</a></li>
                                    <li class="active"><a href="http://localhost/SistemadeLog/View/"><b>Inserir Usuário</b></a></li>				
                                    <li><a href="http://localhost/SistemadeLog/View/"><b>Sair do Sistema</b></a></li>

                                </ul>
                            </div>
                        </form>


                    </div>
                </div>
            </nav>

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-header">
                            <div class="btn-group pull-right" role="group" aria-label="opções">
                                <a href="http://localhost/SistemadeLog/View/" class="btn btn-primary" >Busca Simples <span class="glyphicon glyphicon-usd" aria-hidden="true"></span></a>
                                <a href="http://localhost/SistemadeLog/View/" class="btn btn-primary" >Busca Avançada <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span></a>
                                <a href="http://localhost/SistemadeLog/View/" class="btn btn-primary" >Administrar Usúario <span class="glyphicon glyphicon-search" aria-hidden="true"></span></a>
                            </div>
                            <h1>SGLE  -  <small> Sistema Gerenciar de Log Empresarial</small></h1>
                        </div>
                    </div>	
                </div>
                <h1>Menu  -  <small> Consulta Simples</small></h1>
                <div class="row well noprint">

                    <form class="boxFiltro2 noprint" id="form-busca" method="POST" action="http://localhost/SistemadeLog/View/ConsultaSimples.php">  

                        <h2>Pesquisa</h2>

                        <div class="form-group col-md-2">
                            <label>Data Inicial:</label>
                            <input class="form-control" type="text" name="data1" placeholder="Dia/Mês/Ano" id="outra_data" maxlength="10" onkeypress="mascaraData(this)" class="input-block-level form-control" required=""/>
                            <label>Hora Inicial:</label>
                            <input class="form-control" type="text" name="hora1" placeholder="H:m:s" id="outra_data" maxlength="10" onkeypress="mascaraHora(this)" class="input-block-level form-control" required="" value="16:45:10"/>
                        </div>


                        <div class="form-group col-md-2">
                            <label>Data Final:</label>
                            <input class="form-control" type="text" name="data2" placeholder="Dia/Mês/Ano" id="outra_data" maxlength="10" onkeypress="mascaraData(this)" class="input-block-level form-control" required="" value="13/01/2012"/>
                            <label>Hora Final:</label>
                            <input class="form-control" type="text" name="hora2" placeholder="H:m:s" id="outra_data" maxlength="10" onkeypress="mascaraHora(this)" class="input-block-level form-control" required="" value="16:45:12"/>
                        </div>

                        <div class="form-group col-md-2">
                            <label>IP Usuário:</label>
                            <input type="text" class="form-control span2" name="ip" placeholder="VALOR" maxlength="15" value="" title="">
                        </div>

                        <div class="col-md-12">
                            <hr>	
                            <button type="submit" name="buscar" value="ok" class="btn btn-info ico-search-1">Pesquisar</button>
                        </div>

                    </form>				
                </div>
            </div>

            <script type="text/javascript">
                // select
                var select = document.getElementById("tipo");
                // input
                var input = document.getElementById("diaria");
                // quando o select muda
                select.onchange = function () {
                    var valor = select.options[select.selectedIndex].value;
                    //input.value = valor == 'diaria' ? '* Nome de sua Empresa' : '* Nome Completo';

                    var habilitar = valor == '1' ? true : false;
                    document.getElementById("diaria").readOnly = habilitar;
                    document.getElementById("cargo").readOnly = habilitar;
                    document.getElementById("destino").readOnly = habilitar;
                    document.getElementById("ida").readOnly = habilitar;
                    document.getElementById("volta").readOnly = habilitar;
                    document.getElementById("secretaria").readOnly = habilitar;
                    document.getElementById("empenho").readOnly = !habilitar;
                    document.getElementById("liquidacao").readOnly = !habilitar;
                }
            </script>
            <script type="text/javascript">
                google.charts.load("current", {packages: ["corechart"]});
                google.charts.setOnLoadCallback(drawChart);
                function drawChart() {
                    var data = google.visualization.arrayToDataTable([
                        ['Task', 'Hours per Day'],
                        ['Work', 11],
                        ['Eat', 2],
                        ['Commute', 2],
                        ['Watch TV', 2],
                        ['Sleep', 7]
                    ]);
                    var options = {
                        title: 'Despesa por Fontes',
                        pieHole: 0.4,
                        chartArea: {left: 20, top: 20, width: '50%', height: '75%'},
                    };
                    var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
                    chart.draw(data, options);
                }
            </script>
            <script>
                $(document).on('click', '.delete-object', function () {

                    var id = $(this).attr('delete-id');
                    var q = confirm("Deletar - Confirma?");
                    if (q == true) {

                        $.post('despesas/delete_product.php', {
                            object_id: id
                        }, function (data) {
                            location.reload();
                        }).fail(function () {
                            alert('Impossivel  delete.');
                        });
                    }

                    return false;
                });
            </script>


        </body>
    </html>
    <?php
}
?>
<!DOCTYPE html>

