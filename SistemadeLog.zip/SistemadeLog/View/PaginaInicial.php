
<?php

include_once '../Seguranca.php';

Seguranca::ProtegerSession();


//if (!isset($_SESSION['usuario'])) {
//    header('Location: Login.php');
//}
//
//if($_SESSION["tipo"] == 1){
//  
//    include_once 'menu2.php';
//    
//}else if($_SESSION["tipo"] == 2) {
//  
//    include_once 'menu.contolador.php';
//    
//}else if($_SESSION["tipo"] == 3){
//    
//    include_once 'menu.fornecedor.php';
//}
//
//include_once 'rodape.php';
if (isset($_POST['Entrar'])) {
    Processa();
} else {
    Pagina();
}


function Pagina() {
 ?>
    <html lang="pt-br">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sistema de Guarda de Log</title>
        <link href="../CSS/bootstrap.min.css" rel="stylesheet">
        <link href="../CSS/estilo2.css" rel="stylesheet">
        <script src="../CSS/jquery.min.js.download"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $("input[name="documento"]").blur(function () {
                    var nome = $("input[name="nome"]");
                    //var telefone = $("input[name="telefone"]");

                    $(nome).val("Carregando...");
                    //$( telefone ).val("Carregando...");

                    $.getJSON(
                            "function.php",
                            {nome: $(this).val()},
                            function (json)
                            {
                                $(nome).val(json.nome);
                                //$( telefone ).val( json.telefone );
                            }
                    );
                });
            });
        </script>

        <script type="text/javascript">

            var h = 17;
            < !-- - 3 * 3600 Aqui indicas o número de horas a mais ou a menos do servidor (neste caso 3) -- >
                    var m = 21;
            var s = 09;
            function Relogio() {
                if (s >= 59) {
                    s = -1;
                    m = m + 1;
                    if (m >= 60) {
                        m = 00;
                        h = h + 1;
                        if (h >= 24) {
                            h = 00;
                        }
                    }
                }
                s = s + 1;
                if (h <= 9) {
                    xh = "0" + h;
                } else {
                    xh = h;
                }
                if (m <= 9) {
                    xm = "0" + m;
                } else {
                    xm = m;
                }
                if (s <= 9) {
                    xs = "0" + s;
                } else {
                    xs = s;
                }
                document.getElementById("Relogio").innerHTML = xh + ":" + xm + ":" + xs;
                t = setTimeout("Relogio()", 1000);
            }
            -- >
                    function enviarDados() {
                        for (var i = 0; i < document.form.elements.length; i++) {
                            if (document.form.elements[i].disabled) {
                                document.form.elements[i].disabled = false;
                            }
                        }
                        return true;
                    }
        </script>

        <link id="load-css-0" rel="stylesheet" type="text/css" href="../CSS/tooltip.css">
        <link id="load-css-1" rel="stylesheet" type="text/css" href="../CSS/util.css">
    
    </head>

    <body onload="Relogio();">

        <div class="bs-docs-header" id="content">
            <div class=container>
                <h1>Sistema de Guarda de Log</h1>
                <p><small>----------------------------------------------------------------------------------------</small></p>
            </div>
        </div>



        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                
                
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active">
                            <a class="navbar-brand" href="http://localhost/SistemadeLog/View/Logon.php">Trocar Usúario</a>
                        </li>
                        <li class="active">
                            <a href="http://localhost/SistemadeLog/View/PaginaInicial.php">Inicio</a>
                        </li>
                        <li>
                            <a>
                                <small>OPERANDO POR: Usuario - <span id="Relogio">17:22:38</span></small>
                            </a>
                        </li>
                    </ul>

                    <form class="navbar-form navbar-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-user"><!--Action--></span></button>
                            <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a href="http://www.bandeirantes.pr.gov.br/sisf3/meus_dados.php">Meus Dados</a></li>
                                <li><a href="http://www.bandeirantes.pr.gov.br/sisf3/muda_senha.php">Mudar Senha</a></li>
                                <li class="active"><a href="http://www.bandeirantes.pr.gov.br/sisf3/novo_user.php"><b>Inserir Usuário</b></a></li>				
                                <li><a href="http://www.bandeirantes.pr.gov.br/sisf3/logout.php"><b>Sair do Sistema</b></a></li>

                            </ul>
                        </div>
                    </form>


                </div>
            </div>
        </nav>



        <div class="container">
            <div class="page-header">
                <h1> SGLE <small> - Sistema Gerenciar de Log Empresarial</small></h1>
            </div>
            <p>Selecione abaixo a opção desejada</p>
            <div class="row">
                <div class="col-md-3">
                    <a href="http://localhost/SistemadeLog/View/ConsultaSimples.php" class="btn btn-lg btn-primary btn-block"> Consulta Simples <span class="glyphicon glyphicon-envelope"></span> </a>
                </div>
                <div class="col-md-3">
                    <a href="http://localhost/SistemadeLog/View/ConsultaAvancada.php" class="btn btn-lg btn-primary btn-block"> Consulta Avançada <span class="glyphicon glyphicon-usd"></span> </a>
                </div>
                <div class="col-md-3">
                    <a href="http://localhost/SistemadeLog/View/CadastrarUsuario.php" class="btn btn-lg btn-info btn-block"> Cadastrar Usúario  <span class="glyphicon glyphicon-plane"></span> </a>
                </div>
                <div class="col-md-3">
                    <a href="http://localhost/SistemadeLog/View/AlterarUsuario.php" class="btn btn-lg btn-info btn-block"> Alterar Usúario  <span class="glyphicon glyphicon-list-alt"></span> </a>
                </div>
            </div>
        </div>	
    </body>
</html>

<?php
}



?>

