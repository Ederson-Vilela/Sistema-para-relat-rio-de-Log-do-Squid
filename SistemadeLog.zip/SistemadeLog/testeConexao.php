<?php

include_once './bkpMongo.php';

require_once '../SistemadeLog/Dao/Conexao.php';




//$bkp = new bkpMongo('C:\\MongoDB\\bkp');
////$bkp->run('SistemadeLog',TRUE);        
//$bkp->run('SistemadeLog', true);        

//$Mongo = new MongoClient();
//$DataBase = $Mongo->SistemadeLog;
//
//$Mongo->MongoDumper("C:\MongoDB\bkp");
//$dumper->run("SistemadeLog", true); // 'true' shows debug info

//shell_exec(código);
//
//
//system("mongod C:\MongoDB\bin",$resultado);
//echo $resultado;



//$results = exec('mongodump  --db SistemadeLog | head -5',$data);
//print_r($data);


$resultado = exec("ls C:\MongoDB\bin");
print_r ($resultado);