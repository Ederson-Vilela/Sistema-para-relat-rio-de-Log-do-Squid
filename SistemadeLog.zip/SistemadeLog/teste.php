 <?php

echo gethostbyname("www.uol.com.br") . "\n";

?>