<?php

require_once '../Dao/Dao_Log.php';

class CTL_Log {

    public $dateInicial;
    public $dateFinal;
    public $timeInicial;
    public $timeFinal;

    function InserirLog($ListaLog) {
        $Dao = new Dao_Log();
        if ($ListaLog != NULL) {
            $Dao->insere_Log($ListaLog);
        } else {
            echo 'Lista Vazia';
            ;
        }
    }

    function Busca_SimplesLog($vet) {
        $DAO = new Dao_Log();
        $vetor = array();


        //date_default_timezone_set("Brazil/East");
        $dateInicial = $vet[0] . " " . $vet[1];
        $dateFinal = $vet[2] . " " . $vet[3];

        $dateTime = DateTime::createFromFormat('d/m/Y H:i:s', $dateInicial, new DateTimeZone('Brazil/East'));
        $dateTime2 = DateTime::createFromFormat('d/m/Y H:i:s', $dateFinal, new DateTimeZone('Brazil/East'));

        $timestamp = $dateTime->getTimestamp();
        $timestamp2 = $dateTime2->getTimestamp();

        $vetor[0] = $timestamp;
        $vetor[1] = $timestamp2;
        $vetor[2] = $vet[4];

        $ListLog = $DAO->Busca_SimpesLog($vetor);

        if (!empty($ListLog)) {
            return $ListLog;
        } else {
            return FALSE;
        }
    }

    function Buscar_Avancada($vet) {

        $DAO = new Dao_Log();
        $vetor = array();


        //date_default_timezone_set("Brazil/East");
        $dateInicial = $vet[0] . " " . $vet[1];
        $dateFinal = $vet[2] . " " . $vet[3];

        $dateTime = DateTime::createFromFormat('d/m/Y H:i:s', $dateInicial, new DateTimeZone('Brazil/East'));
        $dateTime2 = DateTime::createFromFormat('d/m/Y H:i:s', $dateFinal, new DateTimeZone('Brazil/East'));

        $timestamp = $dateTime->getTimestamp();
        $timestamp2 = $dateTime2->getTimestamp();

        $vetor[0] = $timestamp;
        $vetor[1] = $timestamp2;
        $vetor[2] = $vet[4];
        $vetor[3] = $vet[5];
        $vetor[4] = $vet[6];
        $vetor[5] = $vet[7];
        $vetor[6] = $vet[8];

 
        $ListLog = $DAO->Buscar_Avancada($vetor);

        if (!empty($ListLog)) {
            return $ListLog;
        } else {
            return FALSE;
        }
    }

    function geraLog($situacao, $login) {
//        $_SERVER['REMOTE_ADDR'];
//        $f = fopen("log.log", "a");
//        fwrite($f, date("d/m/Y H:i") . " $situacao - usuario: $login  " . $_SERVER['REMOTE_ADDR'] . "\n");
//        fclose($f);
    }

    function ConversorDate($vet, $tipo) {
        if ($tipo == 1) {
            date_default_timezone_set("Brazil/East");
            $this->dateInicial = $vet[0] . " " . $vet[1];
            $this->dateFinal = $vet[2] . " " . $vet[3];

            echo $this->dateInicial . "<br>" . $this->dateFinal . "<br><br>";

            $dateTime = DateTime::createFromFormat('d/m/Y H:i:s', $this->dateInicial, new DateTimeZone('Brazil/East'));
            $dateTime2 = DateTime::createFromFormat('d/m/Y H:i:s', $this->dateFinal, new DateTimeZone('Brazil/East'));

            echo $timestamp = $dateTime->getTimestamp() . '<br>';
            echo $timestamp2 = $dateTime2->getTimestamp() . '<br><br>';

            echo date('d/m/Y H:i:s Z', (int) $timestamp) . "<br>";
            echo date('d/m/Y H:i:s Z', (int) $timestamp2) . "<br>";


//            echo $timestamp = strtotime('22-09-2008'). "<br>";
//            echo $timestamp2 = strtotime($this->dateFinal). "<br><br>";
        } else {
            
        }
    }

}
