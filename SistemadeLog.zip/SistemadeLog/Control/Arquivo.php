<?php

require_once '../Model/Log.php';
require_once '../Control/CTL_Log.php';


$ponteiro = fopen("C:\\xampp\\htdocs\\ArquivoSquid_02.txt", "r");
$CTL = new CTL_Log();
$vetor;
$ListaLog = new ArrayObject();

while (!feof($ponteiro)) {
    $vetor = NULL;
    $parte = null;
    $log = new Log();
    $linha = fgets($ponteiro);
    $partes = explode(' ', $linha);

    $i = 0;
    foreach ($partes as $element) {
        if ($element != NULL && $element != "-") {
            $vetor[$i] = $element;
            $i ++;
        }
    }

    date_default_timezone_set("Brazil/East");
    $partes = date('d/m/Y H:i:s', (int) $vetor[0]);

    $log->setData($partes);
    $log->setRequest($vetor[1]);
    $log->setIpUsuario($vetor[2]);
    $log->setAcao($vetor[3]);
    $log->setTamanhoRequest($vetor[4]);
    $log->setMetodo($vetor[5]);
    $log->setUrl($vetor[6]);

    if (count($vetor) == 9) {
        if ($vetor[7] == 'NONE/-') {
            $log->setIpServidor('NEGADO');
            $log->setRequisicao('NEGADO');
            $log->setUsuario('NEGADO');
            $log->setArquivo($vetor[8]);
        } else {
            $partes = explode('/', $vetor[7]);
            $log->setRequisicao($partes[0]);
            $log->setIpServidor($partes[1]);
            $log->setArquivo($vetor[8]);
        }
    }
    if (count($vetor) == 10) {
        $log->setUsuario($vetor[7]);
        $partes = explode('/', $vetor[8]);
        $log->setIpServidor($partes[1]);
        $log->setRequisicao($partes[0]);
        $log->setArquivo($vetor[9]);
    }


//    
//    echo '-' . count($vetor) . '-';

    print_r($vetor);
    echo '<br>';
    echo $log;
//    date_default_timezone_set("Brazil/East");
//    echo date('d/m/Y H:i:s', (int) $vetor[0]);
    echo '<br><br>';

    $ListaLog->append($log);
}

echo count($ListaLog);

fclose($ponteiro);
//$CTL->InserirLog($ListaLog);
