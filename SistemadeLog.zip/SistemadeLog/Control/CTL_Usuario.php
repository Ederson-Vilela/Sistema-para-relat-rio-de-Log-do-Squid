<?php

require_once '../Dao/Dao_Usuario.php';
require_once '../Model/Usuario.php';
include_once '../Seguranca.php';

//Seguranca::ProtegerSession();
//Seguranca::RederecionaUsuario();

class CTL_Usuario {

    function InserirUsuario($user) {
        $DaoUser = new Dao_usuario();
        if ($DaoUser->insere_Usuario($user)) {
            return true;
        } else {
            return false;
        }
    }

    function ValidarLogin($nome, $senha) {

        $Dao_usuario = new Dao_usuario();
        $user = new Usuario();

        $user = $Dao_usuario->BuscarLogin($nome, $senha);
        if ($user) {
            Seguranca::IniciarSessao($user);
            $this->geraLog("sucesso ", $user->getNome());
            Seguranca::RederecionaUsuario();
        } else {
            $login = "Desconhecido";
            $this->geraLog("Falha ao logar ", $nome);
            return FALSE;
        }
    }

    function LocalizarUsuario($nome) {
//        $DaoUser = new Dao_usuario();
//        if ($result = $DaoUser->Buscar_Usuario($nome)) {
//            return $result;
//        } else {
//            return FALSE;
//        }
    }

    function BuscarTodosUsuarios() {
//        $Dao_User = new Dao_usuario();
//        if ($result = $Dao_User->Buscar_TodosUsuario()) {
//            return $result;
//        }
//        return FALSE;
    }

    function BuscarFornecedores() {
//        $Dao_User = new Dao_usuario();
//        if ($result = $Dao_User->Buscar_TodosFornecedores()) {
//            return $result;
//        }
//        return FALSE;
    }

    function AlterarUsuario($user) {
//        $Dao_User = new Dao_usuario();
//        if ($Dao_User->AlterarUsuario($user)) {
//            return TRUE;
//        } else {
//            return FALSE;
//        }
    }

    function geraLog($situacao, $login) {
        $_SERVER['REMOTE_ADDR'];
        $f = fopen("log.log", "a");
        fwrite($f, date("d/m/Y H:i") . " $situacao - usuario: $login  " . $_SERVER['REMOTE_ADDR'] . "\n");
        fclose($f);
    }

    function ExcluirUsuario($nome) {
//        include_once '../Dao/Dao_Usuario.php';
//        $DAO = new Dao_usuario();
//        if($DAO->ExcluirUsuario($nome)){
//            return true;
//        }else{
//            return FALSE;
//        }
    }

    function AssociarProduto($id_user, $id_prod) {
//        $DaoUser = new Dao_usuario();
//        if ($DaoUser->AssociarProduto($id_user, $id_prod)) {
//            return true;
//        } else {
//            return false;
//        }
    }

}
