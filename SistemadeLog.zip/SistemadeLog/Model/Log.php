<?php

//
//if (!isset($_SESSION['usuario'])) {
//    header('Location: ../View/Login.php');
//}
//if (isset($_SESSION['usuario'])) {
//    header('Location: ../View/inicio.php');
//} 

class Log {

    private $id_log;
    private $time;
    private $data;
    private $request;
    private $ipUsuario;
    private $acao;
    private $tamanhoRequest;
    private $metodo;
    private $url;
    private $ipServidor;
    private $requisicao;
    private $usuario;
    private $arquivo;

    function __construct() {
        
    }

    public function __toString() {
        return "Numero de Registro: $this->id_log"
                . "<br> Data: $this->data"
                . "<br> Hora: $this->time"
                . "<br> Tempo de Resposta: $this->request"
                . "<br> IP Usuario: $this->ipUsuario"
                . "<br> Ação do Proxy: $this->acao"
                . "<br> Tamanho da Requisição: $this->tamanhoRequest "
                . "<br> Método de Solicitação: $this->metodo"
                . "<br> Endereço Acessado: $this->url"
                . "<br> IP do Servidor: $this->ipServidor "
                . "<br> Resultado da Requisição: $this->requisicao "
                . "<br> Usuario Solicitante: $this->usuario"
                . "<br> Tipo do Arquivo: $this->arquivo";
    }

    function getRequisicao() {
        return $this->requisicao;
    }

    function setRequisicao($requisicao) {
        $this->requisicao = $requisicao;
    }

    function getId_log() {
        return $this->id_log;
    }

    function getTime() {
        return $this->time;
    }

    function getData() {
        return $this->data;
    }

    function getRequest() {
        return $this->request;
    }

    function getIpUsuario() {
        return $this->ipUsuario;
    }

    function getAcao() {
        return $this->acao;
    }

    function getTamanhoRequest() {
        return $this->tamanhoRequest;
    }

    function getMetodo() {
        return $this->metodo;
    }

    function getUrl() {
        return $this->url;
    }

    function getIpServidor() {
        return $this->ipServidor;
    }

    function getUsuario() {
        return $this->usuario;
    }

    function getArquivo() {
        return $this->arquivo;
    }

    function setId_log($id_log) {
        $this->id_log = $id_log;
    }

    function setTime($time) {
        $this->time = $time;
    }

    function setData($data) {
        $this->data = $data;
    }

    function setRequest($request) {
        $this->request = $request;
    }

    function setIpUsuario($ipUsuario) {
        $this->ipUsuario = $ipUsuario;
    }

    function setAcao($acao) {
        $this->acao = $acao;
    }

    function setTamanhoRequest($tamanhoRequest) {
        $this->tamanhoRequest = $tamanhoRequest;
    }

    function setMetodo($metodo) {
        $this->metodo = $metodo;
    }

    function setUrl($url) {
        $this->url = $url;
    }

    function setIpServidor($ipServidor) {
        $this->ipServidor = $ipServidor;
    }

    function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    function setArquivo($arquivo) {
        $this->arquivo = $arquivo;
    }

}
