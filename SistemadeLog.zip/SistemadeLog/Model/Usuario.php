<?php
//
//if (!isset($_SESSION['usuario'])) {
//    header('Location: ../View/Login.php');
//}
//if (isset($_SESSION['usuario'])) {
//    header('Location: ../View/inicio.php');
//} 

class Usuario {
    private $id_usuario;
    private $nome;
    private $idade;
    private $sexo;
    private $cpf;
    private $email;
    private $estado;
    private $cidade;
    private $rua;
    private $numero;
    private $senha;
    private $nivel;
            
    function __construct() {
        
    }

    public function __toString() {
         return "Id: $this->id_usuario"
                . "<br> Nome: $this->nome"
                . "<br> Idade: $this->idade"
                . "<br> Sexo: $this->sexo"
                . "<br> CPF: $this->cpf"
                . "<br> Email: $this->email"
                . "<br> Estado: $this->estado"
                . "<br> Cidade: $this->cidade"
                . "<br> Rua: $this->rua"
                . "<br> Numero: $this->numero"
                . "<br> Senha: $this->senha"
                . "<br> Nivel: $this->nivel";
    }
    function getId_usuario() {
        return $this->id_usuario;
    }

    function getNome() {
        return $this->nome;
    }

    function getIdade() {
        return $this->idade;
    }

    function getSexo() {
        return $this->sexo;
    }

    function getCpf() {
        return $this->cpf;
    }

    function getEmail() {
        return $this->email;
    }

    function getEstado() {
        return $this->estado;
    }

    function getCidade() {
        return $this->cidade;
    }

    function getRua() {
        return $this->rua;
    }

    function getNumero() {
        return $this->numero;
    }

    function getSenha() {
        return $this->senha;
    }

    function getNivel() {
        return $this->nivel;
    }

    function setId_usuario($id_usuario) {
        $this->id_usuario = $id_usuario;
    }

    function setNome($nome) {
        $this->nome = $nome;
    }

    function setIdade($idade) {
        $this->idade = $idade;
    }

    function setSexo($sexo) {
        $this->sexo = $sexo;
    }

    function setCpf($cpf) {
        $this->cpf = $cpf;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setEstado($estado) {
        $this->estado = $estado;
    }

    function setCidade($cidade) {
        $this->cidade = $cidade;
    }

    function setRua($rua) {
        $this->rua = $rua;
    }

    function setNumero($numero) {
        $this->numero = $numero;
    }

    function setSenha($senha) {
        $this->senha = $senha;
    }

    function setNivel($nivel) {
        $this->nivel = $nivel;
    }



}